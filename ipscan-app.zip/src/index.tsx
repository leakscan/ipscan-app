import React from 'react';
import LiveIPChecker from './components/LiveIPChecker';

export default function Home() {
  return <LiveIPChecker />;
}
