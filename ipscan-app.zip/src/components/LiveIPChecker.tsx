import React, { useState, useEffect } from 'react';
import { Line } from 'react-chartjs-2';

const API_URL = 'https://leakscanner.onrender.com';

export default function LiveIPChecker() {
  const [ip, setIP] = useState('');
  const [trust, setTrust] = useState(null);
  const [abuse, setAbuse] = useState(null);
  const [history, setHistory] = useState([]);
  const [error, setError] = useState(null);

  const headers = { 'x-api-key': process.env.NEXT_PUBLIC_API_KEY };

  const fetchData = async () => {
    try {
      const [trustRes, abuseRes, historyRes] = await Promise.all([
        fetch(`${API_URL}/trustscan/ip/${ip}`, { headers }),
        fetch(`${API_URL}/ip/${ip}/risk`, { headers }),
        fetch(`${API_URL}/ip/${ip}/history`, { headers })
      ]);

      if (!trustRes.ok || !abuseRes.ok || !historyRes.ok) throw new Error('API error');

      const trustData = await trustRes.json();
      const abuseData = await abuseRes.json();
      const historyData = await historyRes.json();

      setTrust(trustData);
      setAbuse(abuseData);
      setHistory(historyData.history);
      setError(null);
    } catch (err) {
      console.error(err);
      setError('Fehler beim Laden der Daten');
    }
  };

  return (
    <div style={{ background: 'black', color: 'white', padding: '2rem', fontFamily: 'Arial' }}>
      <h1>IP Risiko Analyse</h1>
      <input
        type="text"
        value={ip}
        onChange={e => setIP(e.target.value)}
        placeholder="Gib eine IP ein..."
        style={{ padding: '0.5rem', marginRight: '1rem' }}
      />
      <button onClick={fetchData} style={{ padding: '0.5rem' }}>Check</button>

      {error && <p>{error}</p>}

      {trust && (
        <div style={{ marginTop: '1rem' }}>
          <h3>Trustscan:</h3>
          <pre>{JSON.stringify(trust, null, 2)}</pre>
        </div>
      )}

      {abuse && (
        <div style={{ marginTop: '1rem' }}>
          <h3>Abuse Risk Score:</h3>
          <p>
            Score: {abuse.score} {abuse.score > 80 ? '🔥' : abuse.score > 40 ? '⚠️' : '✅'}
          </p>
        </div>
      )}

      {history.length > 0 && (
        <div style={{ marginTop: '2rem' }}>
          <h3>Score Verlauf:</h3>
          <Line
            data={{
              labels: history.map((h, i) => `T-${history.length - i}`),
              datasets: [{
                label: 'Score',
                data: history,
                fill: false,
                tension: 0.1
              }]
            }}
          />
        </div>
      )}
    </div>
  );
}
